import { createContext, useContext, useState } from "react";

const DashboardContext = createContext();
export const DashboardProvider = ({children}) => {
    const [search, setSearch] = useState("");
    return (
        <DashboardContext.Provider value={{search, setSearch}}>
            {children}
        </DashboardContext.Provider>
    )
}

export const useDashoard = () => useContext(DashboardContext);