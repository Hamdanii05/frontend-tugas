import { Route, Routes } from 'react-router-dom';
import './App.css'
import MyNavbar from './Components/MyNavbar/MyNavbar'
import Sidebar from './Components/Sidebar/Sidebar'
import Kategori from './Pages/Kategori/Kategori';
import DashboardLayout from './Pages/DashboardLayout/DashboardLayout';
import Produk from './Pages/Produk/Produk';
import Pesanan from './Pages/Pesanan/Pesanan';
import Pelanggan from './Pages/Pelanggan/Pelanggan';
import Kartu from './Pages/Kartu/Kartu';
import Users from './Pages/Users/Users';
import History from './Pages/History/History';
import AddKategori from './Pages/Kategori/AddKategori';
import EditKategori from './Pages/Kategori/EditKategori';
import AddProduk from './Pages/Produk/AddProduk';
import AddPesanan from './Pages/Pesanan/AddPesanan';
import AddPelanggan from './Pages/Pelanggan/AddPelanggan';
import AddKartu from './Pages/Kartu/AddKartu';

function App() {

  return (
    <>
    <Routes>
      <Route path='/' element={<h1>Hello World</h1>}/>
      <Route path='/dashboard' element={<DashboardLayout />}>
      
      <Route index element={<h1>Dashboard</h1>}/>

      {/*Pesanan*/}
      <Route path='/dashboard/pesanan' element={<Pesanan/>}/>
      <Route path='/dashboard/pesanan/add' element={<AddPesanan/>}/>

      {/*Produk*/}
      <Route path='/dashboard/produk' element={<Produk/>}/>
      <Route path='/dashboard/produk/add' element={<AddProduk/>}/>
      <Route path='/dashboard/produk/edit' element={<h1>Edit Produk</h1>}/>

      {/*Jenis Produk*/}
      <Route path='/dashboard/kategori' element={<Kategori/>}/>
      <Route path='/dashboard/kategori/add' element={<AddKategori />}/>
      <Route path='/dashboard/kategori/edit/:uuid' element={<EditKategori/>}/>


      {/*Pelanggan*/}
      <Route path='/dashboard/pelanggan' element={<Pelanggan/>}/>
      <Route path='/dashboard/pelanggan/add' element={<AddPelanggan/>}/>

      {/*kartu*/}
      <Route path='/dashboard/kartu' element={<Kartu/>}/>
      <Route path='/dashboard/kartu/add' element={<AddKartu/>}/>

      {/*users*/}
      <Route path='/dashboard/users' element={<Users/>}/>

      {/*history*/}
      <Route path='/dashboard/history' element={<History/>}/>
      </Route>
    </Routes>
    </>
  )
}

export default App;
